#!/usr/bin/perl

$num=$ARGV[0];
$file=$ARGV[1];

$count=1;

open(HF,$file) or die("no such file.");
foreach $line (<HF>){
	if ($count == $num){
		print $line;
		last;
	}
	$count++;

}
close(HF);
