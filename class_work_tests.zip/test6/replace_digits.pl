#!/usr/bin/perl


$file=$ARGV[0];

rename ($file, $file.'.bak');
open(IN, '<'.$file.'.bak') or die("no such file.");
open(OUT, '>'.$file) or die("no such file.");
foreach $line (<IN>){
$line=~s/[0-9]/#/g;
print OUT $line;
}
close(IN);
close(OUT);




# foreach $line (<HF>){
# $line=~s/[0-9]/#/g;
# print $line;
# }
# close(HF);
# perl -pi.back -e 's/[0-9]/#/g' $file;
