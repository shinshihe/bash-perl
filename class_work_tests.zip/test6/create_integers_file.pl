#!/usr/bin/perl

#$input = $* ;

#print "$ARGV[0]\n";
#print "$ARGV[1]\n";
#echo $a
$start=$ARGV[0];
$end=$ARGV[1];
$name=$ARGV[2];

#print "$start\n";
#print "$end\n";
#print "$name\n";
open ($FH, '>', $name ) or die $!;
while( "$start" < "$end" ){
	#print "hello";
	print {$FH} $start . "\n";
	$start++;
}
#print {$FH} $start . "\n";
print {$FH} $end . "\n";
close $file;
