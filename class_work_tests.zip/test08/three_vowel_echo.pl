#!/usr/bin/perl
#foreach $word (<STDIN>){
#print $word;
#}
foreach $num (0 .. $#ARGV){
	#print "$ARGV[$num] ";
	#$tmp = $($ARGV[$num] | grep -E "[aeiou]{3}");
	#($tmp) = grep([aeiou]{3},$ARGV[$num]);
	$tmp = $ARGV[$num];
	if ($tmp =~ m/[aeiou]{3}/i){
		print $tmp;
		print " ";
	}
	#print $tmp if $tmp =~ m/[aeiou]{3}/i;
	
} 
print "\n";
