#!/usr/bin/perl
$file = $ARGV[0];
$count = `wc -l < $file`;
#print $count;
@words = ();

open (HF, $file) or die ("No such file");
foreach $line (<HF>){
	push @words,"$line";
	}
close (HF);
$flag = int($count % 2);
if ($flag eq 0){
    $num1 = $count/2;
    print "@words[$num1 -1]";
    print "@words[$num1]";

}else{
    $num1  = int($count/2);
    print "@words[$num1]";
} 