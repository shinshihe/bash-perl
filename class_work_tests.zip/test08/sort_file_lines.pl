#!/usr/bin/perl
sub fun{
    length $::a <=> length $::b;
}
$file= $ARGV[0];
#cat $file | print sort { length($a) <=> length($b) } <>;
open (HF, $file) or die ("No such file");
# foreach $line (<HF>){
# #print $line;
# $len = length($line);
# $newline = $len . '_' . $line;
# print $newline;
# }

#$HF | perl -e print sort { length($a) <=> length($b) } <>;
@words = ();
foreach $line (<HF>){
	push @words,"$line";
	}
close (HF);

while (< >){
    push @words, "$_";
}
#print @words;
print (sort {fun} @words);

#this solution is from satck over flow