#!/bin/bash
sort -t '|' -k 2n | cut -d '|' -f 2 | uniq -c | sed 's/ //g' | grep -e '^2.*$'| sed 's/^.//g' | sort
