#!/bin/bash
#cut -d '|' -f 2,3 | sort | uniq | cut -d '|' -f 2 |  sed 's/\(.*\), \(.*\)/\2/g' | cut -d ' ' -f 2

cut -d '|' -f 2,3 | sort -t '|' -k 2n | uniq | cut -d '|' -f 2 | sed 's/\(.*\), \(.*\)/\2/g' | cut -d ' ' -f 1 | sort


