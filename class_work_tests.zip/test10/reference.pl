#!/usr/bin/perl -w

use strict;



my @words = ();
foreach my $num (<STDIN>){
    # print "num is $num\n";
	push @words,$num;
    }

foreach my $i (@words){
    my $tmp = substr($i,0,1);
    if($tmp eq "#"){
        my $index = substr($i,1,-1);
        print $words[$index-1];
    }else{
        print $i;
    }
}


# foreach my $i (@words){
#     print "element is $i\n";
#     my $tmp = substr($i,0,1);
#     print "sub is $tmp\n";

# }


