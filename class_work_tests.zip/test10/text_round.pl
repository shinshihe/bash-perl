#!/usr/bin/perl -w

sub ha{
    my ($num) = @_;
    $first = substr($num,0,1);
    if($first >= 5){
        return 1;
    }else{
        return 0;
    }

}


use strict;
my @words = ();
foreach my $num ( <STDIN> ){
    # print "num is $num\n";
	push @words,$num;
    }

for my $i (@words){
    if($i=~ m/\d\.\d/){
        my @parts = split('.',$i);
        my $first = $parts[0];
        my $second = $parts[1];
        my $new = '';
        if($i =~ m/\$/){
            print "have \$";
            $first = substr($first,1,-1);
            $second = ha($second);
            $first = $first + $second;
            $new = "\$" . $first;
        }else{
            $second = ha($second);
            $new = $first + $second;
        }
        $i =~ s/$i/$new/;
        print $i;
    }else{
        print $i;
    }
}