#!/usr/bin/perl -w

use strict;

my $len  = scalar @ARGV;
if($len != 2){
    print "Usage: ./echon.pl <number of lines> <string>\n";
    exit;
}
my $first = $ARGV[0];
my $second = $ARGV[1]; 
# if($first =~ m/[a-zA-Z+-_]/){
#     print "./echon.pl: argument 1 must be a non-negative integer\n";
#     exit;
# }

if($first =~ m/[^\d]/){
    print "./echon.pl: argument 1 must be a non-negative integer\n";
    exit;
}


if($first < 0){
    print "./echon.pl: argument 1 must be a non-negative integer\n";
    exit;
}
my $count = 0;
while($count < $first){
    print "$second\n";
    $count++;
}