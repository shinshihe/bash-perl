#!/bin/dash
#read  a b c
#echo $b
a=$1
c=$2
d=$3
#echo $a $c $d
#a=${a[0]}
#c=${a[1]}
#d=${a[2]}
#echo $a $c $d
#echo $a $c
# touch $d
while [ "$a" -lt "$c" ]
do
	echo $a >> $d
	a=$(($a + 1))
done
echo $c >> $d


