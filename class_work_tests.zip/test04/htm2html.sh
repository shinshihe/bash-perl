#!/bin/dash
#IFS=$(echo -en "\n\b")
htm=$(ls *.htm)
html=$(ls *.html 2> /dev/null )
for i in $htm
do
	tmp1=${i%.htm}

	for j in $html
	do
		tmp2=${j%.html}
		if [ "$tmp1" = "$tmp2" ]
		then
			echo "$j exists"
			return 1
		fi
	done	
	#echo ${i%.htm}
done

add=".html"
for i in $htm
do
	tmp=${i%.htm}
	new="$tmp$add"
	mv $i $new 2> /dev/null
done
