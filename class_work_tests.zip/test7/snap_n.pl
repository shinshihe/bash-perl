#!/usr/bin/perl
$num = $ARGV[0];
#print "num is $num";
@words = ();
# while(1){
# 	$flag = 0;
# 	$count = 0;
# 	$line = <STDIN>;
# #	print "$line";
# 	push @words,"$line";
# 	foreach (@words){
# 		if ("$_" eq "$line"){
# 		$count++;
# #		print "count is $count\n";
# 		}
# 		if ("$count" == "$num"){
# 			print "Snap: $line";
# 			$flag = 1;
# 			last;
# 		}
# 	}
# 	if($flag == 1){
# 		last;
# 	}
# }

foreach $line (<STDIN>){
#	print "line is $line";
#	$count = 0;
	push @words,"$line";
	}
#print @words;


foreach $line (@words){
	#print "line is $line";
	$count = 0;
	foreach $gg (@words){
		#print "gg is $gg";
		if ($line eq $gg){
		#	print $gg;
			$count++;
		}
	}
	if($count == $num){
		print "Snap: $line";
		last;
	}
}
