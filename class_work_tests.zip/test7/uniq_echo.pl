#!/usr/bin/perl

use List::MoreUtils qw(uniq);
@array = ();
$num = $#ARGV + 1;
foreach $argnum (0 .. $#ARGV){
#	print "$ARGV[ $argnum]\n";
	
	push @array,"$ARGV[$argnum]";
}
#print "@array\n";
@unic = uniq @array;
print "@unic\n";
